# evidence/ 证据说明

这一目录只放**真实运行产生**的输出，不放手工编写的结论。指导教师按“阶段完成看实现与证据是否一致”核对，因此每条证据都要能对应到代码位置与需求编号。

| 文件 | 是什么 | 证明了什么 | 如何复现 |
| --- | --- | --- | --- |
| `test-2026-11-12.txt` | `npm test` 的完整控制台输出 | 10 个自动化用例全绿（`api.test.js` 1 个 + `stage2.test.js` 9 个），覆盖权限、状态机、配额、时限、幂等与并发约束 | 在项目根目录执行 `npm test *> evidence\test-YYYY-MM-DD.txt` |
| `api-smoke.txt` | 真实服务的接口冒烟记录（只读 + 负例） | 服务能起来；公开接口可用；管理员登录后能读统计/队列/留痕；缺 CSRF 的管理写操作被 403；匿名访问管理端 401 | `npm start` 后另开终端 `node evidence/smoke.mjs`（脚本会把输出写到标准输出） |
| `smoke.mjs` | 冒烟脚本本身 | 冒烟过程可审计、可重跑，不是截图 | 同上；脚本只用 `fetch`，无第三方依赖 |
| `ui-2026-11-12.txt` | Edge 无头浏览器 + DevTools 协议的真实页面检查 | 未登录市场页、未登录访问收藏跳登录、管理员登录、管理工作台、已登录市场、通知、我的发布共 7 个页面渲染正常，且无“暂时无法显示”报错 | `npm start` 后开 `msedge --headless=new --remote-debugging-port=9222 --user-data-dir=<临时目录> about:blank`，再执行 `node scripts/ui-check.mjs` |
| `perf-2026-11-12-before.txt` | 性能优化前的测量（2000 商品 / 500 用户） | 列表接口 P95 = 97.4 ms，暴露出 `GET /api/products` 无 `LIMIT` 的问题 | `node scripts/perf.mjs 200`（脚本自建临时库，不碰 `data/campus.sqlite`） |
| `perf-2026-11-12-after.txt` | 同一负载下优化后的测量 | 列表 P95 降到 2.4 ms、检索 1.7 ms、统计 0.8 ms，满足 QR-01/QR-02 | 同上 |


## 为什么没有“管理员写操作”的冒烟

写操作会改动 `data/campus.sqlite` 里的真实数据，冒烟一旦留下脏数据，后续截图与统计口径就会对不上。管理员写操作的证据由自动化用例承担：`stage2.test.js` 用内存库（`database:':memory:'`）跑完整的“举报 → 处置 → 限制/封禁/下架 → 暂停订单 → 终止释放”链路，结束后库即销毁。

## 与任务卡的对应

| 任务卡 | 主要证据 |
| --- | --- |
| TASK-01 账号与认证 | `test-2026-11-12.txt` 第 1、2 条；`api-smoke.txt` 的 `/api/login`、`/api/me` |
| TASK-02 发布与审核 | `test-2026-11-12.txt` 第 1 条；`api-smoke.txt` 的 `/api/admin/queue` |
| TASK-03 订单闭环 | `test-2026-11-12.txt` 第 1、9 条 |
| TASK-04 生命周期/收藏/咨询 | `test-2026-11-12.txt` 第 3、4、5 条 |
| TASK-05 评价/举报/处置 | `test-2026-11-12.txt` 第 6、7、8 条 |
| TASK-06 统计/留痕/异常订单 | `test-2026-11-12.txt` 第 9、10 条；`api-smoke.txt` 的 `/api/admin/stats`、`/api/admin/audit` |

## 截图的规矩（如果还要补 UI 截图）

- 一张图只说明一件事，截图里要能看见**地址栏或命令提示符**，否则无法证明是本地真实运行。
- 时间顺序要与报告正文一致；日志截图建议同时保留“操作前”和“操作后”两张。
- 不要把开发者的私人信息（浏览器书签、桌面图标、其他项目窗口）带进画面。
