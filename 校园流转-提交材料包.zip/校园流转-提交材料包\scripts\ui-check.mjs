// 用 Edge 的 DevTools 协议做一次真实浏览器冒烟：打开页面、登录、切到各页面，检查 DOM 是否渲染成功。
// 用法：node scripts/ui-check.mjs <baseUrl> <debugPort>
const base = process.argv[2] || 'http://127.0.0.1:3000';
const port = Number(process.argv[3] || 9222);

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function pageWs() {
  for (let i = 0; i < 40; i++) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
      const page = list.find(t => t.type === 'page' && t.webSocketDebuggerUrl);
      if (page) return new WebSocket(page.webSocketDebuggerUrl);
    } catch {}
    await sleep(250);
  }
  throw new Error('连不上 DevTools 端口');
}

const ws = await pageWs();
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0;
const pending = new Map();
ws.onmessage = ev => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
};
function send(method, params = {}) {
  const mid = ++id;
  ws.send(JSON.stringify({ id: mid, method, params }));
  return new Promise(res => pending.set(mid, res));
}
async function evaluate(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
  if (r.result?.exceptionDetails) return { error: r.result.exceptionDetails.text + ' ' + (r.result.exceptionDetails.exception?.description || '') };
  return { value: r.result?.result?.value };
}

const results = [];
async function visit(hash, label, expectText) {
  await evaluate(`location.hash = ${JSON.stringify(hash)}`);
  await sleep(1200);
  const r = await evaluate(`(()=>{const a=document.querySelector('#app');return {text:(a?.innerText||'').replace(/\\s+/g,' ').slice(0,220),busy:a?.getAttribute('aria-busy')}})()`);
  const text = r.value?.text || '';
  const ok = expectText ? text.includes(expectText) : text.length > 0;
  results.push({ label, ok, sample: text.slice(0, 120) });
}

await send('Page.enable');
await send('Runtime.enable');
await send('Page.navigate', { url: base + '/#market' });
await sleep(2500);
const where = await evaluate('document.URL + " | " + document.readyState + " | app=" + !!document.querySelector("#app")');
console.log('navigate ->', JSON.stringify(where.value));

await visit('#market', '未登录·发现闲置', '让闲置继续发光');
await visit('#favorites', '未登录访问收藏 → 应跳登录页', '欢迎回到校园流转');

const login = await evaluate(`(async()=>{
  const me = await (await fetch('/api/me')).json();
  const r = await fetch('/api/login',{method:'POST',headers:{'content-type':'application/json','x-csrf-token':me.csrf},body:JSON.stringify({username:'admin',password:'jKpCTkR9YEBpu4fBy8Ro6uwz'})});
  return (await r.json()).user.role;
})()`);
results.push({ label: '管理员登录', ok: login.value === 'admin', sample: 'role=' + login.value });

await evaluate('refresh()');
await sleep(1200);
await visit('#admin', '管理工作台', '举报处置');
await visit('#market', '发现闲置（已登录）', '让闲置继续发光');
await visit('#notifications', '站内通知', '站内通知');
await visit('#mine', '我的发布', '我的发布');

const errs = await evaluate(`(()=>{const a=document.querySelector('#app');return (a?.innerText||'').includes('暂时无法显示')?'页面报错':'无报错'})()`);
results.push({ label: '渲染异常检查', ok: errs.value === '无报错', sample: String(errs.value) });

for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.label}  ${r.ok ? '' : '| ' + r.sample}`);
const failed = results.filter(r => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} 通过`);
ws.close();
process.exit(failed ? 1 : 0);
