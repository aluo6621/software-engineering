# TASK-06 统计、留痕与异常订单管理

## 关联
- 需求：FR-22 统计、FR-25 异常订单、FR-23 通知；BR-17 统计口径、BR-20 留痕不可删、BR-23 暂停/恢复/终止、QR-09 60s 调度、QR-10 留痕
- 实现：`app.js:96–97`（订单 pause/resume/terminate）、`app.js:100`（stats）、`app.js:101`（audit）、`app.js:26`（expire + 7 天提醒）、`app.js:22–25`（activeOrder/release）
- 测试：`test/stage2.test.js`：管理员暂停恢复终止 + stats + audit、交付满 7 天提醒去重

## 目标
让管理员能「有理有据」地介入争议订单，并且每一步都能在审计里查到。

## 完成定义（可验收）
- 暂停阻止普通推进与超时关闭；恢复时待确认订单重设 48h。
- 终止仅对暂停中订单，落 closed 并按 BR-22 释放商品。
- 统计口径：商品按当前状态、订单按创建时间、用户按注册时间、举报 open/upheld。
- 7 天未确认：双方各一条提醒，重复调度不重复（event_key 唯一）。

## 证据
`test/stage2.test.js` 最后两条通过；`evidence/test-2026-11-12.txt`。

## 状态
已完成
