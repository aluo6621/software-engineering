import test from 'node:test';import assert from 'node:assert/strict';import {createApp} from '../src/app.js';
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';
const DAY=86400000;

function harness(t){
  let time=Date.now();
  const app=createApp({database:':memory:',adminPassword:'AdminPassword123!',clock:()=>time});
  const state={get now(){return time},set now(v){time=v},app};
  return new Promise(resolve=>{
    app.server.listen(0,'127.0.0.1',()=>{
      t.after(()=>new Promise(r=>app.server.close(r)));
      state.base='http://127.0.0.1:'+app.server.address().port;
      resolve(state);
    });
  });
}

function api(h){
  const client=()=>({cookie:'',csrf:''});
  async function req(c,path,method='GET',body,expected=200){const r=await fetch(h.base+'/api'+path,{method,headers:{cookie:c.cookie,'x-csrf-token':c.csrf,'content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});if(r.headers.get('set-cookie'))c.cookie=r.headers.get('set-cookie').split(';')[0];const b=await r.json();assert.equal(r.status,expected,path+' -> '+JSON.stringify(b));if(b.csrf)c.csrf=b.csrf;return b}
  return {client,req};
}

async function seed(h){
  const {client,req}=api(h);
  const admin=client(),seller=client(),buyer=client(),other=client();
  await req(admin,'/login','POST',{username:'admin',password:'AdminPassword123!'});
  for(const [name,c] of [['seller',seller],['buyer',buyer],['other',other]]){
    await req(c,'/register','POST',{username:name,password:'Password123'},201);
    await req(c,'/login','POST',{username:name,password:'Password123'});
  }
  for(const [c,no] of [[seller,'S001'],[buyer,'S002'],[other,'S003']]){
    const cert=await req(c,'/certifications','POST',{realName:'测试学生',studentNo:no},201);
    await req(admin,'/admin/certifications/'+cert.id,'POST',{action:'approve',offlineVerified:true});
  }
  const product=async(c=seller,extra={})=>{
    const p=await req(c,'/products','POST',Object.assign({title:'测试台灯',category:'生活用品',condition:'九成新',description:'功能正常',tradeType:'sale',price:50,images:[png]},extra),201);
    await req(admin,'/admin/products/'+p.id,'POST',{action:'approve'});
    return p.id;
  };
  return {admin,seller,buyer,other,product,req,client};
}

test('未认证用户可收藏与举报，但不能咨询、下单、发布',async t=>{
  const h=await harness(t);const s=await seed(h);
  const fresh=s.client();
  await s.req(fresh,'/register','POST',{username:'nocert',password:'Password123'},201);
  await s.req(fresh,'/login','POST',{username:'nocert',password:'Password123'});
  const pid=await s.product();
  await s.req(fresh,'/products','POST',{title:'x',category:'a',condition:'b',description:'c',tradeType:'gift',images:[png]},403);
  await s.req(fresh,'/products/'+pid+'/inquiries','POST',{content:'还在吗'},403);
  await s.req(fresh,'/orders','POST',{productId:pid,requestKey:'no-cert-1'},403);
  await s.req(fresh,'/favorites/'+pid,'POST',undefined,201);
  await s.req(fresh,'/reports','POST',{targetType:'product',targetId:pid,reasonType:'虚假信息',reason:'描述不符'},201);
  const favs=await s.req(fresh,'/favorites');
  assert.equal(favs.length,1);
  assert.equal(favs[0].id,pid);
});

test('收藏上限 100、重复收藏幂等、取消后释放名额',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  await s.req(s.buyer,'/favorites/'+pid,'POST',undefined,201);
  await s.req(s.buyer,'/favorites/'+pid,'POST',undefined,200);
  const me=h.app.db.prepare("SELECT id FROM users WHERE username='buyer'").get();
  h.app.db.exec('PRAGMA foreign_keys=OFF');
  const insert=h.app.db.prepare('INSERT INTO favorites(user_id,product_id,created_at) VALUES(?,?,?)');
  for(let i=0;i<99;i++)insert.run(me.id,9000+i,Date.now());
  h.app.db.exec('PRAGMA foreign_keys=ON');
  await s.req(s.buyer,'/favorites/'+pid,'DELETE',undefined,200);
  await s.req(s.buyer,'/favorites/'+pid,'POST',undefined,201);
  assert.equal(h.app.db.prepare('SELECT COUNT(*) n FROM favorites WHERE user_id=?').get(me.id).n,100);
});

test('咨询仅双方可见、仅发布者可回复且只能回复一次',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  await s.req(s.seller,'/products/'+pid+'/inquiries','POST',{content:'自己的商品'},403);
  const q=await s.req(s.buyer,'/products/'+pid+'/inquiries','POST',{content:'能便宜点吗'},201);
  const mine=await s.req(s.buyer,'/products/'+pid+'/inquiries');
  assert.equal(mine.length,1);
  const others=await s.req(s.other,'/products/'+pid+'/inquiries');
  assert.equal(others.length,0);
  await s.req(s.other,'/inquiries/'+q.id+'/reply','POST',{content:'我不是卖家'},403);
  await s.req(s.seller,'/inquiries/'+q.id+'/reply','POST',{content:'可以小刀'},200);
  await s.req(s.seller,'/inquiries/'+q.id+'/reply','POST',{content:'再回一次'},409);
  const owner=await s.req(s.seller,'/products/'+pid+'/inquiries');
  assert.equal(owner[0].reply,'可以小刀');
});

test('商品编辑触发重审、交易中禁止下架、主动下架可重提、违规下架为终态',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  await s.req(s.seller,'/products/'+pid,'PATCH',{title:'改名后的台灯'},200);
  assert.equal(h.app.db.prepare('SELECT status FROM products WHERE id=?').get(pid).status,'pending');
  await s.req(s.admin,'/admin/products/'+pid,'POST',{action:'approve'});
  await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'edit-lock-1'},201);
  await s.req(s.seller,'/products/'+pid,'PATCH',{title:'交易中改价'},409);
  await s.req(s.seller,'/products/'+pid+'/status','POST',{action:'offline'},409);
  await s.req(s.seller,'/products/'+pid+'/status','POST',{action:'relist'},409);
  const pid2=await s.product();
  await s.req(s.seller,'/products/'+pid2+'/status','POST',{action:'offline'},200);
  await s.req(s.seller,'/products/'+pid2+'/status','POST',{action:'relist'},200);
  assert.equal(h.app.db.prepare('SELECT status FROM products WHERE id=?').get(pid2).status,'pending');
  h.app.db.prepare("UPDATE products SET status='violation',is_violation=1 WHERE id=?").run(pid2);
  await s.req(s.seller,'/products/'+pid2+'/status','POST',{action:'relist'},409);
});

test('评价仅在完成后14天内、每人每单一次、被评价人可回复一次',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  const o=await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'review-order-1'},201);
  await s.req(s.buyer,'/orders/'+o.id+'/reviews','POST',{rating:5,content:'未完成就评'},409);
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'accept'});
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'deliver',location:'校门',note:'已交付',occurredAt:h.now});
  await s.req(s.buyer,'/orders/'+o.id+'/action','POST',{action:'confirm'});
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'confirm'});
  await s.req(s.other,'/orders/'+o.id+'/reviews','POST',{rating:1},403);
  const rv=await s.req(s.buyer,'/orders/'+o.id+'/reviews','POST',{rating:5,content:'东西很好'},201);
  await s.req(s.buyer,'/orders/'+o.id+'/reviews','POST',{rating:1,content:'再评一次'},409);
  await s.req(s.buyer,'/reviews/'+rv.id+'/reply','POST',{content:'不是被评价人'},403);
  await s.req(s.seller,'/reviews/'+rv.id+'/reply','POST',{content:'谢谢'},200);
  await s.req(s.seller,'/reviews/'+rv.id+'/reply','POST',{content:'再谢一次'},409);
  const sellerId=h.app.db.prepare("SELECT id FROM users WHERE username='seller'").get().id;
  const profile=await s.req(s.buyer,'/users/'+sellerId+'/reviews');
  assert.equal(profile.total,1);
  assert.equal(profile.average,5);
  h.now=h.now+14*DAY+1000;
  await s.req(s.admin,'/login','POST',{username:'admin',password:'AdminPassword123!'});
  await s.req(s.other,'/login','POST',{username:'other',password:'Password123'});
  await s.req(s.seller,'/login','POST',{username:'seller',password:'Password123'});
  const pid2=await s.product();
  const o2=await s.req(s.other,'/orders','POST',{productId:pid2,requestKey:'review-order-2'},201);
  await s.req(s.seller,'/orders/'+o2.id+'/action','POST',{action:'reject',reason:'不出'},200);
  await s.req(s.other,'/orders/'+o2.id+'/reviews','POST',{rating:5},409);
});

test('举报7天内合并、仅本人可查、处置后可限制/封禁、违规下架并暂停订单',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  const r1=await s.req(s.buyer,'/reports','POST',{targetType:'product',targetId:pid,reasonType:'虚假信息',reason:'图不对'},201);
  const r2=await s.req(s.buyer,'/reports','POST',{targetType:'product',targetId:pid,reasonType:'虚假信息',reason:'再补一条证据'},200);
  assert.equal(r2.merged,true);
  assert.equal(r1.id,r2.id);
  const mine=await s.req(s.buyer,'/reports/mine');
  assert.equal(mine.length,1);
  assert.equal((await s.req(s.other,'/reports/mine')).length,0);
  const o=await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'report-order-1'},201);
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'accept'});
  assert.equal(h.app.db.prepare('SELECT paused FROM orders WHERE id=?').get(o.id).paused,0);
  await s.req(s.admin,'/admin/reports/'+r1.id,'POST',{action:'uphold',penalty:'limit',productAction:'violation',reason:'核实违规'},200);
  const p=h.app.db.prepare('SELECT status,is_violation FROM products WHERE id=?').get(pid);
  assert.equal(p.status,'violation');
  assert.equal(p.is_violation,1);
  assert.equal(h.app.db.prepare('SELECT paused FROM orders WHERE id=?').get(o.id).paused,1);
  const seller=h.app.db.prepare("SELECT id,status FROM users WHERE username='seller'").get();
  assert.equal(seller.status,'limited');
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'confirm'},409);
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'resume',reason:'尝试恢复'},409);
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'terminate',reason:'违规终止'},200);
  assert.equal(h.app.db.prepare('SELECT status FROM orders WHERE id=?').get(o.id).status,'closed');
  assert.equal(h.app.db.prepare('SELECT status FROM products WHERE id=?').get(pid).status,'violation');
  await s.req(s.seller,'/products','POST',{title:'受限期间发布',category:'a',condition:'b',description:'c',tradeType:'gift',images:[png]},403);
});

test('限制账号可履行原订单但不能新增交易，封禁后旧会话立即失效',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  const pid2=await s.product();
  const o=await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'limit-order-1'},201);
  await s.req(s.admin,'/admin/users/'+h.app.db.prepare("SELECT id FROM users WHERE username='seller'").get().id+'/status','POST',{action:'limit',reason:'测试限制'},200);
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'accept'},200);
  assert.equal(h.app.db.prepare('SELECT status FROM products WHERE id=?').get(pid2).status,'live');
  await s.req(s.seller,'/products/'+pid2+'/status','POST',{action:'offline'},403);
  const buyerId=h.app.db.prepare("SELECT id FROM users WHERE username='buyer'").get().id;
  await s.req(s.admin,'/admin/users/'+buyerId+'/status','POST',{action:'ban',reason:'恶意下单'},200);
  await s.req(s.buyer,'/orders','POST',{productId:pid2,requestKey:'banned-1'},401);
  assert.equal(h.app.db.prepare('SELECT COUNT(*) n FROM sessions WHERE user_id=?').get(buyerId).n,0);
  await s.req(s.admin,'/admin/users/'+buyerId+'/status','POST',{action:'unban',reason:'申诉通过'},200);
  await s.req(s.buyer,'/login','POST',{username:'buyer',password:'Password123'});
  await s.req(s.buyer,'/orders','POST',{productId:pid2,requestKey:'unbanned-1'},201);
});

test('管理员暂停、恢复、终止订单，统计与操作留痕可查',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  const o=await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'ctrl-order-1'},201);
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'pause',reason:'双方说法不一'},200);
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'accept'},409);
  const before=h.app.db.prepare('SELECT deadline FROM orders WHERE id=?').get(o.id).deadline;
  h.now=h.now+2*DAY;
  await s.req(s.admin,'/login','POST',{username:'admin',password:'AdminPassword123!'});
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'resume',reason:'已核实'},200);
  const after=h.app.db.prepare('SELECT deadline,paused,paused_stage FROM orders WHERE id=?').get(o.id);
  assert.equal(after.paused,0);
  assert.equal(after.paused_stage,'pending');
  assert.ok(after.deadline>=before,'恢复后应重设截止时间');
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'pause',reason:'再次争议'},200);
  await s.req(s.admin,'/admin/orders/'+o.id+'/control','POST',{action:'terminate',reason:'证据充分，终止'},200);
  const closed=h.app.db.prepare('SELECT status,close_reason FROM orders WHERE id=?').get(o.id);
  assert.equal(closed.status,'closed');
  assert.equal(closed.close_reason,'证据充分，终止');
  const stats=await s.req(s.admin,'/admin/stats');
  assert.ok(stats.products.byStatus.live>=1);
  assert.ok(stats.orders.byStatus.closed>=1);
  assert.ok(stats.users.total>=4);
  const auditRows=await s.req(s.admin,'/admin/audit');
  assert.ok(auditRows.some(r=>r.action==='order_pause'));
  assert.ok(auditRows.some(r=>r.action==='order_terminate'));
  await s.req(s.buyer,'/login','POST',{username:'buyer',password:'Password123'});
  await s.req(s.buyer,'/admin/stats','GET',undefined,403);
});

test('交付满7天未完成产生去重提醒，重复调度不重复通知',async t=>{
  const h=await harness(t);const s=await seed(h);
  const pid=await s.product();
  const o=await s.req(s.buyer,'/orders','POST',{productId:pid,requestKey:'remind-order-1'},201);
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'accept'});
  await s.req(s.seller,'/orders/'+o.id+'/action','POST',{action:'deliver',location:'图书馆',note:'已交付',occurredAt:h.now});
  h.now=h.now+7*DAY+1000;
  h.app.expire();
  const key='confirm_remind_'+o.id;
  const count=()=>h.app.db.prepare('SELECT COUNT(*) n FROM notifications WHERE event_key=?').get(key).n;
  assert.equal(count(),2);
  h.app.expire();
  h.app.expire();
  assert.equal(count(),2);
  assert.equal(h.app.db.prepare('SELECT status FROM orders WHERE id=?').get(o.id).status,'confirmation');
});
