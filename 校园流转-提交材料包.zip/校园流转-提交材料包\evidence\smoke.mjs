// 接口冒烟（只读 + 负例）：跑在已启动的服务上，输出可直接作为 evidence。
// 用法：node evidence/smoke.mjs [baseUrl]
const base = process.argv[2] || 'http://127.0.0.1:3000';

const jar = new Map();
function cookieHeader() {
  return [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
}
function saveCookies(res) {
  const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
  for (const raw of list) {
    const [pair] = raw.split(';');
    const i = pair.indexOf('=');
    if (i > 0) jar.set(pair.slice(0, i).trim(), pair.slice(i + 1).trim());
  }
}

async function call(method, path, { body, csrf } = {}) {
  const headers = {};
  if (jar.size) headers.cookie = cookieHeader();
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const res = await fetch(base + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  saveCookies(res);
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* html */ }
  return { status: res.status, json, length: text.length };
}

const out = [];
function line(method, path, status, note) {
  out.push(`${method.padEnd(6)} ${path.padEnd(34)} ${String(status).padEnd(4)} ${note}`);
}

const home = await call('GET', '/');
line('GET', '/', home.status, `HTML ${home.length} B`);

const list = await call('GET', '/api/products');
const listCount = Array.isArray(list.json) ? list.json.length : list.json?.products?.length;
line('GET', '/api/products', list.status, `在售商品 ${listCount ?? '?'} 件`);

const detail404 = await call('GET', '/api/products/999999');
line('GET', '/api/products/999999', detail404.status, '不存在/不可见，预期 404');

const me = await call('GET', '/api/me');
const csrf = me.json?.csrf;
line('GET', '/api/me', me.status, `user=${me.json?.user ? me.json.user.username : 'null'}`);

const login = await call('POST', '/api/login', { body: { username: 'admin', password: process.env.ADMIN_PASSWORD || 'jKpCTkR9YEBpu4fBy8Ro6uwz' }, csrf });
line('POST', '/api/login', login.status, `role=${login.json?.user?.role ?? '-'}`);

const stats = await call('GET', '/api/admin/stats', { csrf });
const pTotal = Object.values(stats.json?.products?.byStatus ?? {}).reduce((a, b) => a + b, 0);
const oTotal = Object.values(stats.json?.orders?.byStatus ?? {}).reduce((a, b) => a + b, 0);
line('GET', '/api/admin/stats', stats.status, `商品 ${pTotal} / 订单 ${oTotal} / 用户 ${stats.json?.users?.total} / 举报未处理 ${stats.json?.reports?.open}`);

const queue = await call('GET', '/api/admin/queue', { csrf });
line('GET', '/api/admin/queue', queue.status, `待审商品 ${queue.json?.products?.length ?? '?'} / 待审认证 ${queue.json?.certifications?.length ?? '?'}`);

const audit = await call('GET', '/api/admin/audit', { csrf });
line('GET', '/api/admin/audit', audit.status, `最近留痕 ${audit.json?.entries?.length ?? '?'} 条`);

const noCsrf = await call('POST', '/api/admin/reports/1', { body: { action: 'dismiss' } });
line('POST', '/api/admin/reports/1（无 CSRF）', noCsrf.status, noCsrf.status === 403 ? '按预期拒绝' : '异常：应 403');

const anon = await (async () => {
  const saved = new Map(jar);
  jar.clear();
  const r = await call('GET', '/api/admin/stats');
  for (const [k, v] of saved) jar.set(k, v);
  return r;
})();
line('GET', '/api/admin/stats（匿名）', anon.status, anon.status === 401 ? '未登录，按预期 401' : '异常：应 401');

console.log(out.join('\n'));
console.log('');
console.log('说明：以上为真实运行输出，可用 node evidence/smoke.mjs 复现（需先 npm start）；管理端写操作会改数据，故此处只做只读与负例验证。');
