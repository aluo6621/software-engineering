import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
const BASE=`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'student',certified INTEGER NOT NULL DEFAULT 0,failed_attempts INTEGER NOT NULL DEFAULT 0,locked_until INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),csrf TEXT NOT NULL,expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS certifications(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),real_name TEXT NOT NULL,student_no TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',reason TEXT,reviewed_by INTEGER REFERENCES users(id),created_at INTEGER NOT NULL,reviewed_at INTEGER);
CREATE UNIQUE INDEX IF NOT EXISTS one_pending_cert ON certifications(user_id) WHERE status='pending';
CREATE UNIQUE INDEX IF NOT EXISTS unique_student_identity ON certifications(student_no) WHERE status='approved';
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,owner_id INTEGER NOT NULL REFERENCES users(id),title TEXT NOT NULL,category TEXT NOT NULL,condition_text TEXT NOT NULL,description TEXT NOT NULL,trade_type TEXT NOT NULL,price INTEGER,expectation TEXT,status TEXT NOT NULL DEFAULT 'pending',review_reason TEXT,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS product_images(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),data_url TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),buyer_id INTEGER NOT NULL REFERENCES users(id),seller_id INTEGER NOT NULL REFERENCES users(id),status TEXT NOT NULL DEFAULT 'pending',paused INTEGER NOT NULL DEFAULT 0,snapshot TEXT NOT NULL,offer TEXT,topup INTEGER NOT NULL DEFAULT 0,payer TEXT,request_key TEXT NOT NULL,deadline INTEGER NOT NULL,created_at INTEGER NOT NULL,delivery TEXT,buyer_confirmed INTEGER NOT NULL DEFAULT 0,seller_confirmed INTEGER NOT NULL DEFAULT 0,cancel_by INTEGER REFERENCES users(id),cancel_status TEXT,cancel_reason TEXT,UNIQUE(buyer_id,request_key));
CREATE UNIQUE INDEX IF NOT EXISTS one_active_order ON orders(product_id) WHERE status IN ('pending','delivery','confirmation');
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL REFERENCES orders(id),actor_id INTEGER REFERENCES users(id),action TEXT NOT NULL,detail TEXT,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),message TEXT NOT NULL,read_at INTEGER,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor_id INTEGER REFERENCES users(id),action TEXT NOT NULL,target TEXT NOT NULL,detail TEXT,created_at INTEGER NOT NULL);
`;
const STAGE2=`
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL REFERENCES users(id),product_id INTEGER NOT NULL REFERENCES products(id),created_at INTEGER NOT NULL,PRIMARY KEY(user_id,product_id));
CREATE TABLE IF NOT EXISTS inquiries(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),asker_id INTEGER NOT NULL REFERENCES users(id),content TEXT NOT NULL,reply TEXT,replied_at INTEGER,created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS inquiry_by_product ON inquiries(product_id,id);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL REFERENCES orders(id),rater_id INTEGER NOT NULL REFERENCES users(id),ratee_id INTEGER NOT NULL REFERENCES users(id),rating INTEGER NOT NULL,content TEXT NOT NULL,reply TEXT,replied_at INTEGER,created_at INTEGER NOT NULL,UNIQUE(order_id,rater_id));
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY,reporter_id INTEGER NOT NULL REFERENCES users(id),target_type TEXT NOT NULL,target_id INTEGER NOT NULL,reason_type TEXT NOT NULL,reason TEXT NOT NULL,group_key TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',penalty TEXT,result TEXT,handled_by INTEGER REFERENCES users(id),handled_at INTEGER,created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS report_group ON reports(group_key,status);
CREATE TABLE IF NOT EXISTS admin_grants(id INTEGER PRIMARY KEY,granted_by INTEGER NOT NULL REFERENCES users(id),target_id INTEGER NOT NULL REFERENCES users(id),action TEXT NOT NULL,created_at INTEGER NOT NULL);
`;
const COLUMNS=[
 ['users','status',"TEXT NOT NULL DEFAULT 'normal'"],
 ['users','limited_until','INTEGER NOT NULL DEFAULT 0'],
 ['users','status_reason','TEXT'],
 ['products','updated_at','INTEGER'],
 ['products','violation_reason','TEXT'],
 ['products','is_violation','INTEGER NOT NULL DEFAULT 0'],
 ['orders','paused_reason','TEXT'],
 ['orders','paused_at','INTEGER'],
 ['orders','paused_stage','TEXT'],
 ['orders','close_reason','TEXT'],
 ['notifications','event_key','TEXT'],
 ['reports','evidence','TEXT'],
 ['orders','completed_at','INTEGER'],
 ['inquiries','replied_by','INTEGER'],
];
export function openDatabase(path){
 if(path!==':memory:')mkdirSync(dirname(path),{recursive:true});
 const db=new DatabaseSync(path);
 db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
 db.exec(BASE);db.exec(STAGE2);
 for(const [table,column,definition] of COLUMNS){
  const exists=db.prepare(`PRAGMA table_info(${table})`).all().some(c=>c.name===column);
  if(!exists)db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
 }
 try{db.exec('CREATE UNIQUE INDEX IF NOT EXISTS one_notice_per_event ON notifications(user_id,event_key) WHERE event_key IS NOT NULL')}catch{}
// S4 性能：列表页/我的页按状态或归属过滤后倒序取前若干条，补覆盖索引避免全表扫描 + 排序。
for(const sql of [
  'CREATE INDEX IF NOT EXISTS product_feed ON products(status,created_at DESC)',
  'CREATE INDEX IF NOT EXISTS product_by_owner ON products(owner_id,created_at DESC)',
  'CREATE INDEX IF NOT EXISTS favorite_by_user ON favorites(user_id,created_at DESC)',
  'CREATE INDEX IF NOT EXISTS order_by_buyer ON orders(buyer_id,created_at DESC)',
  'CREATE INDEX IF NOT EXISTS order_by_seller ON orders(seller_id,created_at DESC)',
])try{db.exec(sql)}catch{}
 return db;
}
