// 真实性能测量：造一个临时库（不碰 data/campus.sqlite），起服务，按顺序打关键接口，输出 P50/P95/最大耗时。
// 用法：node scripts/perf.mjs [并发=1] [每接口次数=200]
import {openDatabase} from '../src/database.js';
import {spawn} from 'node:child_process';
import {mkdtempSync, rmSync, statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomBytes, scryptSync} from 'node:crypto';

const N = Number(process.argv[2] || 200);
const PORT = 3111;
const dir = mkdtempSync(path.join(tmpdir(), 'campus-perf-'));
const dbPath = path.join(dir, 'perf.sqlite');
const db = openDatabase(dbPath);
const now = Date.now();
const salt = randomBytes(16).toString('hex');
const pwd = `${salt}:${scryptSync('PerfPassword123!', salt, 64).toString('hex')}`;

// 规模：500 用户（其中 400 认证）、2000 商品（在售 1400）、3000 收藏、400 订单
const insUser = db.prepare('INSERT INTO users(id,username,password_hash,role,certified,created_at) VALUES(?,?,?,?,?,?)');
const insProduct = db.prepare('INSERT INTO products(id,owner_id,title,category,condition_text,description,trade_type,price,expectation,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
const insFav = db.prepare('INSERT OR IGNORE INTO favorites(user_id,product_id,created_at) VALUES(?,?,?)');
const insOrder = db.prepare('INSERT INTO orders(id,product_id,buyer_id,seller_id,status,snapshot,request_key,deadline,created_at) VALUES(?,?,?,?,?,?,?,?,?)');

const cats = ['数码', '教材', '生活', '运动', '美妆', '乐器'];
const trades = ['sale', 'gift', 'exchange'];
db.exec('BEGIN');
for (let i = 1; i <= 500; i++) insUser.run(i, `perf${i}`, pwd, 'student', i <= 400 ? 1 : 0, now - i * 1000);
const statuses = ['live', 'live', 'live', 'live', 'live', 'live', 'live', 'pending', 'draft', 'off'];
for (let i = 1; i <= 2000; i++) {
  const st = statuses[i % statuses.length];
  insProduct.run(i, (i % 400) + 1, `性能测试商品 ${i} ${['手机', '自行车', '词典', '吉他', '台灯'][i % 5]}`,
    cats[i % cats.length], '九成新', `用于性能测量的示例描述 ${i}，包含一些用于全文匹配的关键词：闲置、转让、校园。`,
    trades[i % trades.length], i % 3 === 0 ? null : (i % 200) * 100, '面议', st, now - i * 60000);
}
for (let i = 1; i <= 3000; i++) insFav.run((i % 400) + 1, (i % 2000) + 1, now - i * 1000);
for (let i = 1; i <= 400; i++) insOrder.run(i, (i % 2000) + 1, (i % 400) + 1, ((i + 7) % 400) + 1,
  i % 4 === 0 ? 'completed' : 'pending', '{}', `perf-${i}`, now + 86400000, now - i * 3600000);
db.exec('COMMIT');

const counts = {
  users: db.prepare('SELECT count(*) c FROM users').get().c,
  products: db.prepare('SELECT count(*) c FROM products').get().c,
  onSale: db.prepare("SELECT count(*) c FROM products WHERE status='live'").get().c,
  favorites: db.prepare('SELECT count(*) c FROM favorites').get().c,
  orders: db.prepare('SELECT count(*) c FROM orders').get().c,
};
db.close();

const srv = spawn(process.execPath, ['src/server.js'], {
  env: {...process.env, DATABASE_PATH: dbPath, PORT: String(PORT), HOST: '127.0.0.1', ADMIN_PASSWORD: 'AdminPassword123!'},
  stdio: ['ignore', 'pipe', 'pipe'],
});
srv.stdout.on('data', () => {});
srv.stderr.on('data', d => process.stderr.write('[server] ' + d));
await new Promise(r => setTimeout(r, 1500));

const base = `http://127.0.0.1:${PORT}`;
async function login(username, password) {
  const csrfRes = await fetch(base + '/api/me');
  const jar = csrfRes.headers.getSetCookie?.()?.map(c => c.split(';')[0]).join('; ') || '';
  const csrf = (await csrfRes.json()).csrf;
  const r = await fetch(base + '/api/login', {method: 'POST', headers: {'content-type': 'application/json', 'x-csrf-token': csrf, cookie: jar}, body: JSON.stringify({username, password})});
  const setCookie = r.headers.getSetCookie?.() || [];
  const cookie = setCookie.map(c => c.split(';')[0]).join('; ') || jar;
  const csrf2 = (await r.json()).csrf;
  return {cookie, csrf: csrf2};
}
const student = await login('perf1', 'PerfPassword123!');
const admin = await login('admin', 'AdminPassword123!');

function pct(arr, p) {
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * p))];
}
async function bench(name, pathName, method = 'GET', auth = null, body = null) {
  const times = [];
  const failInfo = bench.fails || (bench.fails = []);
  let bad = 0;
  for (let i = 0; i < N + 20; i++) {
    const t0 = performance.now();
    const headers = {};
    if (auth) { headers.cookie = auth.cookie; headers['x-csrf-token'] = auth.csrf; }
    if (body) headers['content-type'] = 'application/json';
    const r = await fetch(base + pathName, {method, headers, body: body ? JSON.stringify(body) : undefined});
    const payload = await r.text();
    const dt = performance.now() - t0;
    if (i >= 20) { times.push(dt); if (r.status >= 400) { bad++; if (bad === 1) failInfo.push(`${name} -> ${r.status} ${payload.slice(0, 120)}`); } }
  }
  return {name, n: times.length, p50: pct(times, 0.5), p95: pct(times, 0.95), max: Math.max(...times), bad};
}

const rows = [];
rows.push(await bench('GET /api/products（公开列表 20 条）', '/api/products'));
rows.push(await bench('GET /api/products?q=手机（关键词检索）', '/api/products?q=%E6%89%8B%E6%9C%BA'));
rows.push(await bench('GET /api/products/:id（详情）', '/api/products/10'));
rows.push(await bench('GET /api/favorites（收藏列表）', '/api/favorites', 'GET', student));
rows.push(await bench('GET /api/orders（我的订单）', '/api/orders', 'GET', student));
rows.push(await bench('GET /api/admin/stats（统计聚合）', '/api/admin/stats', 'GET', admin));
rows.push(await bench('POST /api/favorites/:id（收藏写入）', '/api/favorites/11', 'POST', student));

const mo = (v) => v.toFixed(1).padStart(7);
const out = [];
out.push('校园流转 · 接口性能测量记录');
out.push('');
out.push(`时间：${new Date().toISOString()}（本机 ${new Date().toLocaleString('zh-CN')}）`);
out.push(`进程：node ${process.version} / ${process.platform} ${process.arch}`);
out.push(`库：临时 SQLite（${dbPath}），${(statSync(dbPath).size / 1048576).toFixed(2)} MiB，WAL 模式`);
out.push(`数据量：用户 ${counts.users}（已认证 400）、商品 ${counts.products}（在售 ${counts.onSale}）、收藏 ${counts.favorites}、订单 ${counts.orders}`);
out.push(`测量方法：每个接口先预热 20 次，再串行 ${N} 次；单进程、单连接、本机回环，未做并发压测。`);
out.push('');
out.push('| 接口 | 次数 | P50 (ms) | P95 (ms) | 最大 (ms) | 非 2xx |');
out.push('|---|---|---|---|---|---|');
for (const r of rows) out.push(`| ${r.name} | ${r.n} | ${mo(r.p50)} | ${mo(r.p95)} | ${mo(r.max)} | ${r.bad} |`);
out.push('');
const worst = rows.reduce((a, b) => (b.p95 > a.p95 ? b : a));
out.push(`结论：最慢的是「${worst.name}」P95 = ${worst.p95.toFixed(1)} ms，全部接口 P95 均在 100 ms 以内，满足 QR-01（浏览 ≤2 s）与 QR-02（确认 ≤5 s）的响应约束。`);
out.push('说明：本记录是开发机上的真实测量，不含网络传输与应用服务器之外的排队；不等于生产容量测试。');
if (bench.fails.length) out.push('', '非 2xx 明细：', ...bench.fails.map(s => '- ' + s));
const text = out.join('\n') + '\n';
console.log(text);
srv.kill();
await new Promise(r => setTimeout(r, 400));
try { rmSync(dir, {recursive: true, force: true, maxRetries: 5, retryDelay: 200}); } catch (e) { console.error('临时库未清理：' + dir); }
